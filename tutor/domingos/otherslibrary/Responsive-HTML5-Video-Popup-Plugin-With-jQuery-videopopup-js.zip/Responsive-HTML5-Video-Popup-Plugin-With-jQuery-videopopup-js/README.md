# html5-video-popup-responsive
A simple script jquery embedding a video clip in a modal window. Video is responsive.

<br />


More on and DEMO [HTML5 responsive popup video](https://netteria.net/html5-video-popup-jquery/105/)<br>
Create by [Netteria.NET](https://netteria.net) 2017.
