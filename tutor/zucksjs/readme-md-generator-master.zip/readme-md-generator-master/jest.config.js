module.exports = {
  collectCoverageFrom: [
    './src/**/*.js',
    '!./src/index.js',
    '!**/node_modules/**',
    '!**/vendor/**'
  ]
}
