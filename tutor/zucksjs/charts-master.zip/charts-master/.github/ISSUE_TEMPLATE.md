#### Expected Behaviour

#### Actual Behaviour

#### Steps to Reproduce:
*

NOTE: Add a GIF/Screenshot if required.

Frappé Charts version:
