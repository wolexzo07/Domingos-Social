import * as Charts from './chart';

let frappe     = { };

frappe.NAME    = 'Frappe Charts';
frappe.VERSION = '1.2.0';

frappe         = Object.assign({ }, frappe, Charts);

export default frappe;