import Page from "@daybrush/page";
import { add } from "./Store";

const page3 = new Page(".page.page3");

add(page3);
