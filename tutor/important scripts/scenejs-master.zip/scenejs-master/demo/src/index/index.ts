import "./MainPage";
import "./FeaturesPage";
import "./ExamplesPage";
import "./StartedPage";
import "./Header";
import { scroll } from "./Store";
import "./css/index.css";
import "./css/page1.css";
import "./css/page2.css";
import "./css/page3.css";
import "./css/page4.css";

scroll();
