import Page from "@daybrush/page";
import { add } from "./Store";

const page4 = new Page(".page.page4");

add(page4);
