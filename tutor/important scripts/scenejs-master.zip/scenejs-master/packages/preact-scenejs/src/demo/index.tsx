import { render, h } from "preact";
import App from "./App";

render(<App />, document.getElementById("root")!);
