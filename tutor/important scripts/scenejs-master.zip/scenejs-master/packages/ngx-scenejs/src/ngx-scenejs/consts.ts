export const EVENT_MAP = {
  paused: 'scenePaused',
  timeupdate: 'sceneTimeUpdate',
  iteration: 'sceneIteration',
  animate: 'sceneAnimate',
  play: 'scenePlay',
  ended: 'sceneEnded',
};
