(function () {
    window.dataLayer = window.dataLayer || [];
    function gtag() { dataLayer.push(arguments); }
    gtag('js', new Date());

    gtag('config', 'UA-128864447-1');
    var script = document.createElement("script");

    script.src = "https://www.googletagmanager.com/gtag/js?id=UA-128864447-1";

    document.body.appendChild(script);
})();
