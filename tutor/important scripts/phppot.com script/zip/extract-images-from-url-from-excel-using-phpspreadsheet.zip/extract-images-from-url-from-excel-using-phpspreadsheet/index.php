<?php
use \Phppot\ExcelImportService;

require_once 'class/ExcelImportService.php';

$excelImportService = new ExcelImportService();
$excelDataArray = $excelImportService->loadExcel();
if (! empty($excelDataArray)) {
    $isNewData = $excelImportService->importImages($excelDataArray);
    if ($isNewData) {
        $message = "Images extracted from excel successfully!";
    } else {
        $message = "No new images found during the excel extract!";
    }
}
$imageResult = $excelImportService->getAllImages();
?>

<!doctype html>
<html>
<head>

<link rel="stylesheet" type="text/css" href="CSS/style.css">
<title>Extract Images from URL in Excel using PHPSpreadSheet with PHP</title>

</head>
<body>
    <div id="gallery">

        <div id="image-container">
            <h2>Extract Images from URL in Excel using PHPSpreadSheet
                with PHP</h2>
                <?php
                if (! empty($message)) {
                    ?>
            <div id="txtresponse"><?php echo $message; ?></div>
            <?php
                }
                ?>
            <ul id="image-list">
                <?php
                if (! empty($imageResult)) {
                    foreach ($imageResult as $k => $v) {
                        ?>
                        <li><img
                    src="<?php echo $imageResult[$k]['image_path']; ?>"
                    class="image-thumb"
                    alt="<?php echo $imageResult[$k]['image_name'];?>"></li>
                        <?php
                    }
                }
                ?>
             </ul>

        </div>

    </div>
</body>
</html>
