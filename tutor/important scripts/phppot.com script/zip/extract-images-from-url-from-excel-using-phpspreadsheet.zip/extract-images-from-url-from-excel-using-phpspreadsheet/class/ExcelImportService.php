<?php 
namespace Phppot;

use \Phppot\DataSource;

require 'vendor/PhpSpreadsheet/autoload.php';

class ExcelImportService {
    
    private $ds;
    
    function __construct()
    {
        require_once __DIR__ . './DataSource.php';
        $this->ds = new DataSource();
    }
    
    private function isUrlExist($url)
    {
        $query = 'SELECT * FROM tbl_images where remote_url = ?';
        $paramType = 's';
        $paramValue = array($url);
        $count = $this->ds->numRows($query, $paramType, $paramValue);
        return $count;
    }
    
    private function extractImage($url) 
    {
        $path = pathinfo($url);
        
        $imageTargetPath = 'uploads/' . time() . $path['basename'];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, false);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // <-- important to specify
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); // <-- important to specify
        $resultImage = curl_exec($ch);
        curl_close($ch);
        
        $fp = fopen($imageTargetPath, 'wb');
        fwrite($fp, $resultImage);
        fclose($fp);
        
        $imageInfo["image_name"] = $path['basename'];
        $imageInfo["image_path"] = $imageTargetPath;
        
        return $imageInfo;
    }
    
    private function saveImagePath($imageInfo, $remoteUrl) {
        $query = "INSERT INTO tbl_images (image_name,image_path, remote_url) VALUES (?, ?, ?)";
        $paramType = 'sss';
        $paramValue = array($imageInfo["image_name"], $imageInfo["image_path"], $remoteUrl);
        $this->ds->insert($query, $paramType, $paramValue);
    }
    
    public function loadExcel() 
    {
        //create directly an object instance of the IOFactory class, and load the xlsx file
        $xlsFile ='Excel_Template/imageURLs.xlsx';
        
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($xlsFile);
        
        //read excel data and store it into an array
        $excelData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
        $rowCount = count($excelData);
        $urlArray = array();
        for($i=2;$i<$rowCount;$i++) {
            $url = $excelData[$i]['A'];
            if(!empty($url)) {
                $urlArray[] = $url;
            }
        }
        return $urlArray;
    }
    
    public function importImages($excelDataArray) 
    {
        $isNewData = false;
        foreach($excelDataArray as $url) {
            
            $isUrlExist = $this->isUrlExist($url);
            
            if (empty($isUrlExist)) {
                
                $imageInfo = $this->extractImage($url);
                
                if(!empty($imageInfo)) {
                    $this->saveImagePath($imageInfo, $url);
                }
                $isNewData = true;
            }
        }
        return $isNewData;
    }
    
    public function getAllImages() 
    {
        $query = 'SELECT * FROM tbl_images';
        $result = $this->ds->select($query);
        return $result;
    }
}