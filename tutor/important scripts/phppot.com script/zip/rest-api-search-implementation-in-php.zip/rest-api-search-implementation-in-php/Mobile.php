<?php
require_once("dbcontroller.php");
/* 
A domain Class to demonstrate RESTful web services
*/
Class Mobile {
	private $mobiles = array();
	public function searchMobile(){
		if(isset($_GET['name'])){
			$name = $_GET['name'];
			$query = "SELECT * FROM tbl_mobile WHERE name LIKE '%" .$name. "%'";
		} else {
			$query = "SELECT * FROM tbl_mobile";
		}
		$dbcontroller = new DBController();
		$this->mobiles = $dbcontroller->executeSelectQuery($query);
		return $this->mobiles;
	}	
}
?>