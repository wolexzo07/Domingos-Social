<?php include 'DBController.php';
$db_handle = new DBController();
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<meta name="viewport" content="initial-scale=1">
<!-- Main CSS -->
<link rel="stylesheet" href="main.css">
</head>
<body>
    <div id="gridview">
        <div class="heading">Custom Image Explorer</div>
        <div class="btn">
            <form name='subimg' id="subimg" method="post" action="" enctype="multipart/form-data">
                <button class="gallery-icon" id="gallery-icon" name="gallery-icon" >Gallery view</button>
                <button class="list-icon" id="list-icon" name="list-icon">List view</button> 
                <input type="button" class="slideshow-icon" id="slideshow-icon" name="slideshow-icon" value="Slideshow"> 
            </form> 
        </div>
        
<?php
$query = $db_handle->runQuery("SELECT * FROM tbl_image ORDER BY id ASC");
if (! empty($query)) {
    foreach ($query as $key => $value) {
        if(isset($_POST['list-icon'])){ ?>  
       
        <div class="image small">
                <img src="<?php echo $query[$key]["image_path"] ; ?>" />
                <?php echo $query[$key]["name"] ; ?>
            </div>
<?php   }else {?>
            <div class="image display-inline-block">
                <img src="<?php echo $query[$key]["image_path"] ; ?>" />
            </div>
<?php   
        }    
    }
}
?> 
<div class="galleryShadow"></div>
        <div class="galleryModal">
          <i class="galleryIcon gIquit close"></i>
          <i class="galleryIcon gIleft nav-left"></i>
          <i class="galleryIcon gIright nav-right"></i>
          <div class="galleryContainer">
              <img src="">
          </div> 
        </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <!-- Main JS -->
<script src="main.js"></script>
</body>
</html>
