<?php
require_once "handler.php";
$uploader = new UploadHandler();

$uploader->allowedExtensions = array(); // all files types allowed by default

$uploader->sizeLimit = null;

$uploader->inputName = "qqfile"; // matches Fine Uploader's default inputName value by default

$uploader->chunksFolder = "../../data/chunks";

$method = get_request_method();

function get_request_method() {
    global $HTTP_RAW_POST_DATA;

    if(isset($HTTP_RAW_POST_DATA)) {
    	parse_str($HTTP_RAW_POST_DATA, $_POST);
    }

    if (isset($_POST["_method"]) && $_POST["_method"] != null) {
        return $_POST["_method"];
    }

    return $_SERVER["REQUEST_METHOD"];
}

if ($method == "POST") {
    header("Content-Type: text/plain");

    if (isset($_GET["done"])) {
        $result = $uploader->combineChunks("../../data");
    }
    else {
        $result = $uploader->handleUpload("../../data");

        $result["uploadName"] = $uploader->getUploadName();
    }

    echo json_encode($result);
}
else if ($method == "DELETE") {
    $result = $uploader->handleDelete("../../data");
    echo json_encode($result);
}
else {
    header("HTTP/1.0 405 Method Not Allowed");
}
?>
