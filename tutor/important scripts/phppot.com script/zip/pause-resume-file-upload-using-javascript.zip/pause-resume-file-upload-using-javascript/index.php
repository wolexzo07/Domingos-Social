<html>
<head>
<title>Pause Resume File Upload using jQuery</title>
<style>
.box-width{width: 1000px;margin:10px;}
body{width:600px;font-family:calibri;}   	
</style>
<link href="vendor/fine-uploader/fine-uploader-gallery.min.css" rel="stylesheet">
<script src="vendor/fine-uploader/fine-uploader.min.js"></script>
<?php require_once("vendor/fine-uploader/templates/gallery.html"); ?>	
</head>	
<body>
<div class="box-width" id="file-drop-area"></div>
<script>
var uploader = new qq.FineUploader({
	debug: true,
	element: document.getElementById('file-drop-area'),
	request: {
		endpoint: "view/fine-uploader/endpoint.php"
	},
	uploadSuccess: {
		endpoint: "view/fine-uploader/endpoint.php?success",
		params: {
			isBrowserPreviewCapable: qq.supportedFeatures.imagePreviews
		}
	},
	chunking: {
		enabled: true
	},
	resume: {
		enabled: true
	},
	deleteFile: {
		enabled: true,
		method: "POST",
		endpoint: "view/fine-uploader/endpoint.php"
	},
	validation: {
		itemLimit: 10,
		sizeLimit: 350000000
	},
	thumbnails: {
		placeholders: {
			notAvailablePath: "vendor/fine-uploader/placeholders/not_available-generic.png",
			waitingPath: "vendor/fine-uploader/placeholders/waiting-generic.png"
		}
	},
});
</script>
</body>		
</html>