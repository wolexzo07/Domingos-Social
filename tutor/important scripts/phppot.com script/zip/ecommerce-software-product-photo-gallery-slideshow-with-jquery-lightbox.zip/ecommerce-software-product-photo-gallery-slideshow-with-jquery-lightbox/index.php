<?php
include 'DBController.php';
$db_handle = new DBController();
?>
<!doctype html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="initial-scale=1">
<!-- Main CSS -->
<link rel="stylesheet" href="assets/css/main.css">

<title>eCommerce Software Product Gallery Slideshow with jQuery Lightbox</title>
</head>
<style>
body {
    max-width: 960px;
    margin: 0 auto;
    font-family: arial;
}

.galleryItem {
    width: 300px;
    display: inline-block;
}

.galleryItem img {
    width: 100%;
}
</style>
<body>
    <div class="container py-4">
        <h1>eCommerce Software Product Gallery Slideshow with jQuery Lightbox</h1>
        <div>
            <!-- gallery class need for using gallery -->
            <div class="gallery">
                <!-- need a div for contains img tag -->
          <?php
        $query = $db_handle->runQuery("SELECT * FROM tbl_products ORDER BY id ASC");
        if (! empty($query)) {
            foreach ($query as $key => $value) {
                ?> 
          <div class="galleryItem">
                    <img src="<?php echo $query[$key]["product_image"] ; ?>"
                        data-text="<?php echo $query[$key]["name"] ; ?>">
                </div>
          <?php
            }
        }
        ?>
        </div>
        </div>
    </div>
    <div class="galleryShadow"></div>
        <div class="galleryModal">
          <i class="galleryIcon gIquit close"></i>
          <i class="galleryIcon gIleft nav-left"></i>
          <i class="galleryIcon gIright nav-right"></i>
          <div class="galleryContainer">
              <img src="">
          </div>  
        </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
</body>
</html>
