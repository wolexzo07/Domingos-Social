<?php
require_once ('db.php');
?>
<!doctype html>
<head>
<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>

<script type="text/javascript" src="vendor/dialogify/dialog-polyfill.js"></script>
<script type="text/javascript" src="vendor/dialogify/dialogify.js"></script>

<script type="text/javascript"
    src="vendor/dialogify/dialogify.min.js?v2"></script>

<script type="text/javascript" src="editRecords.js"></script>

<link rel="stylesheet" type="text/css" media="all"
    href="vendor/dialogify/dialogify.css">
<link rel="stylesheet" type="text/css" media="all" href="style.css">
</head>
<body>

    <h2>Add Edit Comments using jQuery Dialogify</h2>

    <div id="container">
            <?php
            $selectQuery = "SELECT * FROM tbl_comments";
            $result = $conn->query($selectQuery);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="comment-row">

            <div id="editFrame">

                <div id="name_val<?php echo $row['id']; ?>">
                                        <?php echo $row['name']; ?>
                                    </div>
                <div id="website_val<?php echo $row['id']; ?>">
                                        <?php echo $row['website']; ?>
                                    </div>

                <div id="content_val<?php echo $row['id']; ?>"
                    class="comment-message">
                                        <?php echo $row['content']; ?>
                                    </div>
                <input type='button' class="btn-edit"
                    id="<?php echo $row['id']; ?>" value="Edit"
                    onclick="edit_row('<?php echo $row['id']; ?>');" />

            </div>
        </div>

                    <?php
                }
            }
            ?>
            <input id="insert_button" type="button" class="btn-submit"
            value="Create a comment" />
    </div>
</body>
</html>
