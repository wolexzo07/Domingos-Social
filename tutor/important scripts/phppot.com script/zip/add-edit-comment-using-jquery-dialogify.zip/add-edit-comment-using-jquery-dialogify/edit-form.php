<input type="text" class="text-field form-control" id="username"
    placeholder="Name" />
<input type="text" class="text-field form-control" id="website"
    placeholder="link" />
<textarea type="text" class="text-field form-control" id="edit_content"
    placeholder="content"></textarea>

<script>
 $(document).ready(function () {
     var name = localStorage.getItem('name');
	 var website = localStorage.getItem('website');
	 var content = localStorage.getItem('content');
    $('#username').val(name);
    $('#website').val(website);
    $('#edit_content').val(content);
 });
 </script>