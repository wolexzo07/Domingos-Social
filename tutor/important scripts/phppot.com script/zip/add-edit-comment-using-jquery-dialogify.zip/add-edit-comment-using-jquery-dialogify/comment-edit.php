<?php
require_once('db.php');

if (isset($_POST['edit_row'])) {
    $sql = $conn->prepare("UPDATE tbl_comments SET name=? , website=? , content=?  WHERE id=?");
    $id = $_POST['id'];
    $name = $_POST['name'];
    $website = $_POST['website'];
    $content = $_POST['content'];

    $sql->bind_param("sssi", $name, $website, $content, $id);
    if ($sql->execute()) {
        print "success";
    } else {
        $error_message = "Problem in Editing Record";
    }
}
?>