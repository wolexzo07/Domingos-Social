<input type="text" class="text-field form-control" id="username"  placeholder="Name"/>
<input type="text" class="text-field form-control" id="website"   placeholder="Website"/>
<textarea type="text" class="text-field form-control" id="new_content"   placeholder="content"></textarea>