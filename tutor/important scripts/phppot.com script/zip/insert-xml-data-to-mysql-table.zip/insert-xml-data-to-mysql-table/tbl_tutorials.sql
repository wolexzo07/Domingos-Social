CREATE TABLE IF NOT EXISTS `tbl_tutorials` (
`item_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `description` varchar(400) NOT NULL,
  `keywords` varchar(50) NOT NULL
);