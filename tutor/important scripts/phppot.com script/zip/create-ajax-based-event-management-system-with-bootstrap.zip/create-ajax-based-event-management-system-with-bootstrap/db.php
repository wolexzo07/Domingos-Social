<?php 
$connect = new PDO('mysql:host=localhost;dbname=blog_samples', 'root', 'test');
?>