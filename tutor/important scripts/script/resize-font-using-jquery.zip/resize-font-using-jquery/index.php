<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Resize font using JQuery</title>
</head>
<style>
* { 
font-family:Tahoma, Geneva, sans-serif; 
line-height:2; 
}
.container { 
width:900px; 
margin:0 auto; 
position:relative; 
top:80px; 
}
#changesize {
position:fixed;
top:5px;
left:500px;
padding:5px;
}
.increase, .decrease, .reset {
float:left;
margin:10px;
}
</style>
<script type="text/javascript" src="jquery-1.8.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
  // Reset Font Size
  var defaultsize = $('html').css('font-size');
  $(".reset").click(function(){
  $('html').css('font-size', defaultsize);
  return false;
  });
  // Increase Font Size
  $(".increase").click(function(){
  	var currentfontsize = $('html').css('font-size');
 	var incfontsize = parseFloat(currentfontsize, 10);
    var newsize = incfontsize*1.5;
	$('html').css('font-size', newsize);
	return false;
  });
  // Decrease Font Size
  $(".decrease").click(function(){
  	var currentfontsize = $('html').css('font-size');
 	var decfontsize = parseFloat(currentfontsize, 10);
    var newsize = decfontsize*0.8;
	$('html').css('font-size', newsize);
	return false;
  });
});
</script>
<body>

<div class="container"> 
This is arunkumar maha founder at www.2my4edge.com. <br /> Meaning of 2my4edge ( it stands for 'to my four edge'. ).<br /> Sample text from <a href="http://www.2my4edge.com">www.2my4edge.com</a>. <br /> for this tutorial <a href=""> Resize font using Jquery </a> <br /> For more Demos <a href="http://demos.2my4edge.com"> demos.2my4edge.com </a> <br /> Click the above bottons to make increase and decrease of font size.
</div>
<div id="changesize">
<a href="#" class="increase"><img src="increase.png" /></a>
<a href="#" class="decrease"><img src="decrease.png" /></a>
<a href="#" class="reset"><img src="reset.png" /></a>
</div>
</body>
</html>
