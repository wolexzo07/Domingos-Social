php-scripts
===========

several different,useful php scripts and functions
