<?php
require_once('config.php' );

if(isset($_POST["processthis"]) && $_POST["processthis"]=="yes")
{
$regFields='[{"name":"name"},
			{"name":"color","description":"Your fev Color","type":"text"},
			{"name":"from","description":"Where are u From?","type":"text"},
			{"name":"like","description":"Do you like saaraan.com?","type":"checkbox"}]';

	echo '<div id="registration_form" style="width:560px;height:330px;" align="center">
	<fb:registration 
	fields=\''.$regFields.'\' 
	redirect-uri="'.$redirect_url.'receive_data.php" 
	width="530">
	</fb:registration>
	</div>';
}
?>