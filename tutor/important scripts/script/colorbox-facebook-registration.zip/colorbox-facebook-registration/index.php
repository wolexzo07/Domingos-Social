<?php
require_once('config.php' );
session_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Facebook Connect & Facebook Registration Part I</title>
    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="colorbox/jquery.colorbox-min.js"></script>
    <link href="colorbox/colorbox.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="fb-login-wrapper">
    	<div class="fb-login-button" onlogin="javascript:registerme();" size="medium" scope="publish_stream,email">Login</div>
    </div>
    <div id="fb-root"></div>
    <script type="text/javascript">
    window.fbAsyncInit = function() {
    FB.init({
    appId:  '<?php echo $appId; ?>',
    cookie: true,
    xfbml: true,
    oauth: true, 
    display:'popup'});
    };
    (function() {var e = document.createElement('script');
    e.async = true;e.src = document.location.protocol +'//connect.facebook.net/en_US/all.js';
    document.getElementById('fb-root').appendChild(e);}());
    function registerme(){
            FB.login(function(response) {		
            if (response.status === "connected") 
            {
            var alldata =  {processthis: "yes"};
            $.colorbox({href:"process.php",data:alldata,onClosed:function(){ $("#fb-login-wrapper").show(); },onComplete:function(){FB.XFBML.parse(); }});
            }
        });
    }
    </script>
    <?php
    
    if(isset($_SESSION['facebook_data']))
    {
            //registration data sent from receive_data.php file
            $userid = $_SESSION['facebook_data']["user_id"];
            $fullname = $_SESSION['facebook_data']["registration"]["name"];
            $usercolor = $_SESSION['facebook_data']["registration"]["color"];
            $userfrom = $_SESSION['facebook_data']["registration"]["from"];
            $userlike = $_SESSION['facebook_data']["registration"]["like"];
            
            //Now we have user data, we can store it in database or just prepare for output
            $facebookData = array('Facebook User ID'=>$userid,'Name'=>$fullname,'Favorite Color'=>$usercolor,'Location'=>$userfrom,'Likes Saaraan'=>$userlike.' (0=No|1=Yes)');
            
            //Output this data
            echo '<pre>';
            print_r($facebookData);
            echo '<pre>';
    
    //distroy session
    session_destroy();
    }		
    ?>
</body>
</html>
