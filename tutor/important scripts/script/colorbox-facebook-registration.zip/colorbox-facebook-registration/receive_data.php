<?php
require_once('config.php' );

session_start();

if(isset($_POST["signed_request"])){ //receive user data from facebook
$signedresponse = parse_signed_request($_REQUEST["signed_request"], $appSect);
	if($signedresponse)
	{
		//Receive facebook data and redirect user to homepage with session variable
		$_SESSION['facebook_data'] = $signedresponse;
		header('Location: '.$redirect_url);
	}
}

//function to phrase signed data from facebook.
function parse_signed_request($signed_request, $secret) {
		  list($encoded_sig, $payload) = explode('.', $signed_request, 2); 
		  $sig = base64_url_decode($encoded_sig);
		  $data = json_decode(base64_url_decode($payload), true);
		
		  if (strtoupper($data['algorithm']) !== 'HMAC-SHA256') {
			die('Unknown algorithm. Expected HMAC-SHA256');
			return null;
		  }
		  $expected_sig = hash_hmac('sha256', $payload, $secret, $raw = true);
		  if ($sig !== $expected_sig) {
			die('Bad Signed JSON signature!');
			return null;
		  }
		  return $data;
	}
	
function base64_url_decode($input) {
		return base64_decode(strtr($input, '-_', '+/'));
}

?>