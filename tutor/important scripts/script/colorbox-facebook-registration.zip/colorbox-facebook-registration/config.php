<?php
########## (Replace with yours) #############
$appId = 'xxxxxx'; // your app id here
$appSect = 'xxxxxx'; // your app secret
$redirect_url = "http://localhost/colorbox/"; //path
?>