<?php
if(isset($_POST["url"]))
{
	$share_url = filter_var($_POST["url"], FILTER_SANITIZE_URL);

	echo '<ul class="sw-loaded-buttons">';
	
	echo '<li>';
	echo '<iframe src="//www.facebook.com/plugins/like.php?href='.urlencode($share_url);
	echo '&amp;width&amp;layout=box_count&amp;action=like&amp;show_faces=false&amp;';
	echo 'share=false&amp;height=65&amp;appId=365936720119443" scrolling="no" frameborder="0" style="border:none;'; 
	echo 'overflow:hidden; height:65px;" allowTransparency="true"></iframe>';
	echo '</li>';
	
	echo '<li>';
	echo '<iframe allowtransparency="true"  frameborder="0" scrolling="no" ';
	echo 'src="https://platform.twitter.com/widgets/tweet_button.html?count=vertical" ';
	echo 'style="width:50px; height:65px;"></iframe>';
	echo '</li>';
	
	echo '<li style="height: 70px;margin-bottom:10px;overflow: hidden;">';
	echo '<iframe src="https://plusone.google.com/_/+1/fastbutton?bsv&amp;size=tall&amp;hl=en-US&amp;url='.urlencode($share_url);
	echo '&amp;parent='.urlencode($share_url).'" allowtransparency="true" frameborder="0" scrolling="no" title="+1"></iframe>';
	echo '</li>';
	
	echo '</ul>';
	echo '<div class="sw-close-btn">&times;</div>';

}
?>