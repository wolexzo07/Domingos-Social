<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Share icon</title>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready( function(){
var loaded = false; //buttons loaded status
var pageUrl = location.href; //location of this page

$("a.sw-share-icon").on( "click", function(event) { 
	event.preventDefault(); //stop going to URL
});	

$('a.sw-share-icon').mouseenter(function() { //on mouse enter
	$(".sw-share-icon").removeClass("xspin").addClass("yspin"); //remove xspin and add yspin class  
		var showing = $(".sw-share-buttons").css("display"); //wrapper display status
		if(showing=="none")
		{
			//animate slide in from top
			$(".sw-share-buttons").css("marginTop", "-100px").show().animate({opacity: 1, marginTop:'1px'},200);
			if(!loaded){ //load buttons if not already loaded
				$.ajax({ //ajax load buttons
					  type: "POST",
					  url: "share_load.php",
					  data: {url: pageUrl} //post page url
				}).done(function( msg ) {
					 $( "#sw-share-result" ).html(msg); //load buttons inside #sw-share-result
				 });
				loaded = true; //change loaded status
				
			}
		}	
});	

//use clicked close button
$( "div.sw-share-wrp" ).on( "click", "div.sw-close-btn", function(event){
	$(".sw-share-icon").removeClass("yspin").addClass("xspin"); //remove yspin and add xspin class 
	$(".sw-share-buttons").animate({opacity: 0, marginTop:'-100px'},100).hide(200); //animate slide up effect
});

});
</script>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>


<div class="sw-share-wrp">
	<a href="#" class="sw-share-icon" rel="nofollow">&nbsp;</a>
    <div class="sw-share-buttons">
    <div class="sw-circle"></div>
    <div id="sw-share-result"><img class="sw-share-loading-img" src="ajax-loader.gif" /></div>
    </div>
</div>


<div style="width:600px;margin-left:auto;margin-right:auto;">
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec fermentum sem diam, non pretium velit adipiscing sit amet. Sed vel blandit enim, non pulvinar ligula. Suspendisse faucibus nunc risus, quis interdum sem aliquet quis. Aenean egestas luctus sem quis interdum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi scelerisque vehicula consequat. Etiam lacus ante, gravida placerat mollis id, ultrices vitae libero. Donec feugiat non tellus sed porta. Integer scelerisque facilisis turpis eu placerat. In nec aliquam leo.

Phasellus eget sagittis eros. Proin eget sollicitudin neque, sed lobortis sem. Nam massa eros, sagittis nec augue id, faucibus varius magna. Ut lacinia, felis in imperdiet accumsan, velit augue placerat leo, ut tempor arcu ante eget sapien. In ac nisi imperdiet, lobortis nulla eu, pellentesque magna. Aenean porttitor metus risus, nec malesuada enim aliquet vel. Etiam pellentesque aliquet ante vel mattis. Fusce id tellus ut arcu ornare rutrum. Fusce sit amet orci consequat elit scelerisque ornare in a dolor. Nunc vel nisl ac odio faucibus sodales nec sed neque. Curabitur blandit egestas lobortis.

Suspendisse euismod felis ac malesuada ornare. Phasellus euismod tempus consectetur. Integer sollicitudin ullamcorper dolor nec viverra. Proin a facilisis mi. Ut suscipit porttitor eros, quis sodales velit dapibus ac. Fusce venenatis ac ipsum et mollis. Morbi sollicitudin turpis at luctus placerat. Curabitur dapibus augue vel lacus rhoncus, eu consectetur eros dignissim. Integer molestie risus nec nulla dignissim tempor. Proin at accumsan elit, eget scelerisque tortor.

Nam tincidunt vestibulum felis id ultrices. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam auctor, augue eget varius rhoncus, mi erat luctus lectus, convallis rutrum erat tortor ut risus. Donec urna enim, fermentum sit amet congue at, condimentum vel nisl. Suspendisse potenti. Sed imperdiet nisl nec laoreet pretium. Maecenas in volutpat quam. In cursus eget turpis vitae gravida. In eget congue nunc. Fusce quis leo nec turpis laoreet imperdiet. Mauris nisi tellus, vestibulum nec mattis et, imperdiet nec sapien. Maecenas elementum viverra tellus, eu placerat augue aliquam non. Maecenas nec laoreet nisl, et malesuada lectus. Pellentesque magna felis, condimentum vitae elit sed, pulvinar pharetra nunc. Maecenas dignissim sed libero vitae dapibus. Praesent facilisis nisi ut felis consequat viverra.

Donec velit mi, suscipit nec tellus ut, tristique porttitor lorem. Nulla eget mi sed orci vehicula iaculis. Phasellus lacinia velit at diam placerat, non convallis magna imperdiet. Morbi eu eleifend felis, eu facilisis quam. Fusce turpis nulla, suscipit eget enim et, pellentesque egestas enim. Aenean sit amet risus consequat, porttitor augue ac, luctus felis. Maecenas egestas aliquam sapien. Donec laoreet nibh eu arcu dictum, eu molestie orci pharetra. Morbi ullamcorper a nisi eu ultricies. Pellentesque accumsan pellentesque ullamcorper. Maecenas non neque sapien.

Curabitur ut enim et odio pretium rutrum id consequat dolor. Vestibulum a bibendum lorem. Mauris porta, quam in volutpat vestibulum, felis tortor laoreet leo, id sollicitudin libero nisl non magna. Curabitur sed fringilla justo, eget euismod lorem. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed id sagittis felis. Proin pharetra luctus urna, et congue lectus semper sit amet. Praesent pharetra nec est vitae lobortis. Phasellus fringilla quis sapien nec lobortis. Aenean tristique velit eget est feugiat pretium. Sed interdum velit est.

Maecenas tempus at odio non consectetur. Vivamus et quam egestas, lobortis mauris sed, pellentesque dui. In hac habitasse platea dictumst. Ut vulputate enim id lacus interdum fermentum. Vestibulum convallis venenatis mi nec fringilla. Aliquam sapien justo, varius pellentesque varius sed, congue non massa. Curabitur eget odio dictum, pellentesque mauris commodo, congue est. Cras porttitor ultricies tempus. Donec tristique erat ac lacus sollicitudin, vel aliquam elit vulputate. In eget libero vel enim dictum varius gravida sit amet sem.

Fusce non egestas lacus, et euismod tortor. Praesent a ullamcorper turpis. Curabitur sodales turpis non lorem hendrerit, vel venenatis nunc pretium. In ante felis, pellentesque et tempor eu, egestas non diam. Fusce lobortis, dui nec adipiscing aliquam, dui purus fringilla magna, at rhoncus nisl magna eget mi. Vivamus nec eleifend ipsum, non gravida erat. Phasellus scelerisque, purus a interdum congue, lacus turpis ultricies urna, vitae sollicitudin dui ligula a neque. Vestibulum pretium erat eu enim gravida, sed tempus dolor dictum. Aliquam porttitor dui ut leo egestas, nec laoreet sapien bibendum. Morbi id tempus diam, vitae vestibulum purus.

Nunc imperdiet erat in ante pharetra, vitae ultrices libero gravida. Cras tristique id lectus ac vestibulum. Duis ut dolor aliquet felis consequat convallis. Curabitur in orci mattis, ultrices augue eu, volutpat nisl. Nam tristique dictum dictum. Praesent sed felis blandit, semper felis vel, dapibus enim. Nunc accumsan accumsan eros sollicitudin interdum.

Mauris blandit consectetur urna. Vestibulum eu ullamcorper sapien, ac ultricies leo. Cras elit tortor, ultrices ut purus at, placerat feugiat elit. Praesent turpis nibh, luctus ac enim eu, pulvinar feugiat diam. Aenean sed sollicitudin odio. Pellentesque quis risus sit amet sapien placerat laoreet. Integer eget mauris sit amet erat posuere molestie sed in sem. Etiam id sodales sapien. Mauris ut diam massa. Maecenas venenatis aliquam massa eu vulputate. Phasellus euismod, augue vel pretium tincidunt, justo nibh porttitor mi, vitae ullamcorper neque ipsum sed risus. 
</div>
</body>
</html>