<style type="text/css">
td { border-bottom:#CCC 1px solid; border-right:#999 1px solid; padding:10px; }
</style>
<?php
include('db.php');
$per_page = 1; 
if($_GET)
{
$page=$_GET['page'];
}
$start = ($page-1)*$per_page;
$select_table = "select * from pagination order by id limit $start,$per_page";
$variable = mysql_query($select_table);
?>
	<table width="800px">
		<?php
		$i=1;
		while($row = mysql_fetch_array($variable))
		{
            $name=$row['name'];
			$design=$row['designation'];
			$place=$row['place'];
		?>
		<tr>
        <td style="color:#999;"><?php echo $i++; ?></td>
        <td><?php echo $name; ?></td>
        <td><?php echo $design; ?></td>
        <td><?php echo $place; ?></td></tr>
		<?php
		}
		?>
</table>