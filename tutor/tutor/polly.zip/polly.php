<?php
//download the amazon php sdk from here - http://docs.aws.amazon.com/aws-sdk-php/v3/download/aws.zip
require '/path/to/aws-autoloader.php'; //change this path

use Aws\Polly\PollyClient;

if(isset($_REQUEST['voice']) && $_REQUEST['voice'] != '')
{
    $voice_id = $_REQUEST['voice'];
} else {
    $voice_id="Joanna";
}

if(isset($_REQUEST['text']) && $_REQUEST['text'] != '')
{
    $text = trim(strip_tags($_REQUEST['text']));
}


if(isset($_REQUEST['rate']) && $_REQUEST['rate']!=''){
    $rate=$_REQUEST['rate'];
}else{
    $rate="medium";
}

$is_download = false;
if(isset($_REQUEST['download']) && $_REQUEST['download']==1){
    $is_download=true;
}


$config = [
                'version'     => 'latest',
                'region'      => 'us-east-1',
                'credentials' => [
                    'key'    => 'Access Key',
                    'secret' => 'Secret Key',
                ]
        ];


 $client     = new PollyClient($config);
  $args = [
                'OutputFormat' => 'mp3',
                'Text' =>  "<speak><prosody rate='$rate'>".str_replace("&","&amp;",urldecode ($text))."</prosody></speak>",
                'TextType'     => 'ssml',
                'VoiceId' => $voice_id,
            ];
        $result     = $client->synthesizeSpeech($args);          
        
        $resultData     = $result->get('AudioStream')->getContents();


$size   = strlen($resultData); // File size
$length = $size;           // Content length
$start  = 0;               // Start byte
$end    = $size - 1;       // End byte
	

if(!$is_download) {
header('Content-Transfer-Encoding:chunked');
header("Content-Type: audio/mpeg");
header("Accept-Ranges: 0-$length");
header("Content-Range: bytes $start-$end/$size");
header("Content-Length: $length");
echo $resultData;
} else {
header('Content-length: ' . strlen($resultData));
header('Content-Disposition: attachment; filename="polly-text-to-speech.mp3"');
header('X-Pad: avoid browser bug');
header('Cache-Control: no-cache');
echo $resultData;
}
?>