------------------
Entypo Glyph Set (284 glyphs)
Designed by Daniel Bruce (http://danielbruce.se/) and released for the Web design community.
------------------

Dear Friends,

Thank you for downloading this file.

This freebie has been brought to you by SmashingMagazine.com. You can freely use it for both your private and commercial projects, including software, online services, templates and themes. Please always credit the original designer of the set (in this case, Daniel Bruce). The icons may not be resold, sublicensed, rented, transferred or otherwise made available for use. 

The Entypo pictograms are licensed under CC BY 3.0 and the font under SIL Open Font License.

The rights to each pictogram in the social extention are either trademarked or copyrighted by the respective company.

Please link to the article in which this freebie was released if you would like to spread the word.

Smashing Magazine Team,
www.smashingmagazine.com
